import React from "react";
import "./Header.css";

function Header() {
  return (
    <div className="header">
      <div className = 'header_abc_products'>
        <h2>ABC PRODUCT 🅰️🅰️</h2>
      </div>
      <div className ='header_hrc_logo'>
        
         <h1>HIGHRADIUS</h1>
      </div>
      <div className="header_invoice_list">Invoice List</div>
    </div>
  );
}

export default Header;
